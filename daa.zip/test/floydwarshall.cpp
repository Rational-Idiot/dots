#include <bits/stdc++.h>
using namespace std;

#define INF 1e9

int main() {
  int n;
  cin >> n;

  int dist[n][n];

  // input matrix
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      cin >> dist[i][j];

      if (i != j && dist[i][j] == 0)
        dist[i][j] = INF;
    }
  }

  // Floyd–Warshall
  for (int k = 0; k < n; k++) {
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < n; j++) {

        if (dist[i][k] != INF && dist[k][j] != INF &&
            dist[i][k] + dist[k][j] < dist[i][j]) {

          dist[i][j] = dist[i][k] + dist[k][j];
        }
      }
    }
  }

  // output
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      if (dist[i][j] == INF)
        cout << "INF ";
      else
        cout << dist[i][j] << " ";
    }
    cout << endl;
  }
}
