int LIS(int arr[], int n) {
  int dp[n];
  for (int i = 0; i < n; i++)
    dp[i] = 1;

  int max = 1;

  for (int i = 1; i < n; i++) {
    for (int j = 0; j < i; j++) {
      if (arr[i] > arr[j] && dp[i] < dp[j] + 1)
        dp[i] = dp[j] + 1;
    }
    if (dp[i] > max)
      max = dp[i];
  }
  return max;
}
