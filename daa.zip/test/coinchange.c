#include <limits.h>
#include <stdio.h>

#define MIN(x, y) ((x) < (y) ? (x) : (y))

int coinChange(int coins[], int n, int amount) {
  int count = 0;

  for (int i = n - 1; i >= 0; i--) {
    while (amount >= coins[i]) {
      amount -= coins[i];
      count++;
    }
  }
  return (amount == 0) ? count : -1;
}

int DyncoinChange(int coins[], int n, int amount) {
  int dp[amount + 1];

  // initialize
  dp[0] = 0;
  for (int i = 1; i <= amount; i++)
    dp[i] = INT_MAX;

  for (int i = 1; i <= amount; i++)
    for (int j = 0; j < n; j++)
      if (coins[j] <= i && dp[i - coins[j]] != INT_MAX)
        dp[i] = MIN(dp[i], 1 + dp[i - coins[j]]);

  return (dp[amount] == INT_MAX) ? -1 : dp[amount];
}
