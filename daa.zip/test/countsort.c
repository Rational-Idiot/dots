#include <stdio.h>
#include <stdlib.h>

void Sort(int arr[], int n) {
  int max = arr[0];
  for (int i = 1; i < n; i++) {
    max = (arr[i] > max) ? arr[i] : max;
  }

  int *count = (int *)calloc(max + 1, sizeof(int));
  int *output = (int *)malloc(sizeof(int) * n);
  for (int i = 0; i < n; i++) {
    ++count[arr[i]];
  }

  for (int i = 1; i < max + 1; i++) {
    count[i] = count[i] + count[i - 1];
  }
  for (int i = n; i-- > 0;) {
    int val = arr[i];
    output[count[val] - 1] = val;
    count[val]--;
  }

  for (int i = 0; i < n; i++) {
    arr[i] = output[i];
  }
  free(output);
  free(count);
}

int main() {
  int n;
  scanf("%d", &n);

  int arr[n];
  for (int i = 0; i < n; i++) {
    scanf("%d", &arr[i]);
  }
  Sort(arr, n);

  for (int i = 0; i < n; i++) {
    printf("%d ", arr[i]);
  }
  return 0;
}
