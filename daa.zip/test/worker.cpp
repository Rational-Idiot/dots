#include <bits/stdc++.h>
using namespace std;

const int INF = 1e9;

int bfs(int s, int t, vector<vector<int>> &cap, vector<vector<int>> &adj,
        vector<int> &parent) {

  fill(parent.begin(), parent.end(), -1);
  parent[s] = -2;

  queue<pair<int, int>> q;
  q.push({s, INF});

  while (!q.empty()) {
    int u = q.front().first;
    int flow = q.front().second;
    q.pop();

    for (int v : adj[u]) {
      if (parent[v] == -1 && cap[u][v] > 0) {
        parent[v] = u;

        int new_flow = min(flow, cap[u][v]);

        if (v == t)
          return new_flow;

        q.push({v, new_flow});
      }
    }
  }
  return 0;
}

int maxFlow(int s, int t, vector<vector<int>> &cap, vector<vector<int>> &adj) {

  int flow = 0;
  vector<int> parent(cap.size());
  int new_flow;

  while ((new_flow = bfs(s, t, cap, adj, parent))) {
    flow += new_flow;

    int cur = t;
    while (cur != s) {
      int prev = parent[cur];
      cap[prev][cur] -= new_flow;
      cap[cur][prev] += new_flow;
      cur = prev;
    }
  }

  return flow;
}

int main() {
  int N, M, E;
  cin >> N >> M >> E;

  int S = 0;
  int T = N + M + 1;

  int V = N + M + 2;

  vector<vector<int>> cap(V, vector<int>(V, 0));
  vector<vector<int>> adj(V);

  // source → workers
  for (int i = 1; i <= N; i++) {
    cap[S][i] = 1;
    adj[S].push_back(i);
    adj[i].push_back(S);
  }

  // jobs → sink
  for (int j = 1; j <= M; j++) {
    cap[N + j][T] = 1;
    adj[N + j].push_back(T);
    adj[T].push_back(N + j);
  }

  // qualifications: worker → job
  for (int i = 0; i < E; i++) {
    int w, j;
    cin >> w >> j;

    cap[w][N + j] = 1;
    adj[w].push_back(N + j);
    adj[N + j].push_back(w);
  }

  cout << maxFlow(S, T, cap, adj) << endl;
}
