#include <stdio.h>
#include <stdlib.h>

long long fib(int n) {
  long long result;
  long long *dp = (long long *)malloc((n + 1) * sizeof(long long));
  if (n <= 1) {
    free(dp);
    return n;
  }
  dp[0] = 0;
  dp[1] = 1;
  for (int i = 2; i < n + 1; i++) {
    dp[i] = dp[i - 2] + dp[i - 1];
  }
  result = dp[n];
  free(dp);
  return result;
}

int main() {
  int n;
  scanf("%d", &n);
  printf("%lld\n", fib(n));
  return 0;
}
