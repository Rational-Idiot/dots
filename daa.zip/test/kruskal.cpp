#include <bits/stdc++.h>
using namespace std;

struct Edge {
  int u, v, w;
};

bool cmp(Edge a, Edge b) { return a.w < b.w; }

int parent[100], rnk[100];

int find(int x) {
  if (parent[x] != x)
    parent[x] = find(parent[x]);
  return parent[x];
}

void unite(int a, int b) {
  a = find(a);
  b = find(b);

  if (a != b) {
    if (rnk[a] < rnk[b])
      parent[a] = b;
    else if (rnk[a] > rnk[b])
      parent[b] = a;
    else {
      parent[b] = a;
      rnk[a]++;
    }
  }
}

int main() {
  int n;
  cin >> n;

  int mat[100][100];
  vector<Edge> edges;

  for (int i = 0; i < n; i++)
    for (int j = 0; j < n; j++)
      cin >> mat[i][j];

  // build edge list
  for (int i = 0; i < n; i++) {
    for (int j = i + 1; j < n; j++) {
      if (mat[i][j] != 0)
        edges.push_back({i, j, mat[i][j]});
    }
  }

  sort(edges.begin(), edges.end(), cmp);

  for (int i = 0; i < n; i++) {
    parent[i] = i;
    rnk[i] = 0;
  }

  cout << "MST edges:\n";

  for (auto e : edges) {
    if (find(e.u) != find(e.v)) {
      cout << e.u << " - " << e.v << " : " << e.w << endl;
      unite(e.u, e.v);
    }
  }
}
