#include <bits/stdc++.h>
using namespace std;

#define INF 1e9

int main() {
  int n, src;
  cin >> n >> src;

  int graph[n][n];

  for (int i = 0; i < n; i++)
    for (int j = 0; j < n; j++)
      cin >> graph[i][j];

  vector<int> dist(n, INF);
  vector<bool> visited(n, false);

  dist[src] = 0;

  for (int count = 0; count < n - 1; count++) {

    int u = -1;
    int minDist = INF;

    // pick minimum distance unvisited node
    for (int i = 0; i < n; i++) {
      if (!visited[i] && dist[i] < minDist) {
        minDist = dist[i];
        u = i;
      }
    }

    visited[u] = true;

    // relax all edges from u
    for (int v = 0; v < n; v++) {
      if (graph[u][v] && !visited[v] && dist[u] + graph[u][v] < dist[v]) {

        dist[v] = dist[u] + graph[u][v];
      }
    }
  }

  for (int i = 0; i < n; i++) {
    cout << "Distance to " << i << " = " << dist[i] << endl;
  }
}
