#include <bits/stdc++.h>
using namespace std;

int main() {
  int n, m;
  cin >> n >> m;

  vector<vector<int>> adj(n);
  vector<int> indegree(n, 0);

  for (int i = 0; i < m; i++) {
    int u, v;
    cin >> u >> v;

    adj[u].push_back(v);
    indegree[v]++;
  }

  queue<int> q;

  // push nodes with 0 indegree
  for (int i = 0; i < n; i++) {
    if (indegree[i] == 0)
      q.push(i);
  }

  vector<int> topo;

  while (!q.empty()) {
    int u = q.front();
    q.pop();

    topo.push_back(u);

    for (int v : adj[u]) {
      indegree[v]--;

      if (indegree[v] == 0)
        q.push(v);
    }
  }

  // check cycle
  if (topo.size() != n) {
    cout << "Graph has cycle (not DAG)\n";
    return 0;
  }

  for (int x : topo)
    cout << x << " ";
}
