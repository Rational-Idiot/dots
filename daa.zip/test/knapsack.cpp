#include <bits/stdc++.h>
using namespace std;

int knapsack(int W, vector<int> &wt, vector<int> &val, int n) {
  vector<vector<int>> dp(n + 1, vector<int>(W + 1, 0));

  for (int i = 1; i <= n; i++) {
    for (int w = 0; w <= W; w++) {

      // don't take item
      dp[i][w] = dp[i - 1][w];

      // take item if possible
      if (wt[i - 1] <= w) {
        dp[i][w] = max(dp[i][w], val[i - 1] + dp[i - 1][w - wt[i - 1]]);
      }
    }
  }

  return dp[n][W];
}

int main() {
  vector<int> wt = {1, 2, 3};
  vector<int> val = {6, 10, 12};
  int W = 5;

  cout << knapsack(W, wt, val, wt.size()) << endl;
}
