#include <stdio.h>
#define p(a) printf(" %d\n", a)
#define f(a, b, i) for (int i = a; i < b; i++)

void swap(int *a, int *b) {
  int temp = *a;
  *a = *b;
  *b = temp;
}

int partition(int a[], int l, int r) {
  int j = l;
  f(l, r, i) {
    if (a[i] < a[r]) {
      swap(&a[i], &a[j]);
      j++;
    }
  }
  swap(&a[j], &a[r]);
  return j;
}

void quicksort(int a[], int l, int r) {
  if (l >= r)
    return;
  int pv = partition(a, l, r);
  quicksort(a, l, pv - 1);
  quicksort(a, pv + 1, r);
}

int main() {
  int n;
  scanf("%d", &n);
  int a[n];
  f(0, n, i) { scanf("%d", &a[i]); }
  f(0, n, i) { printf(" %d", a[i]); }
  printf("\n");
  quicksort(a, 0, n - 1);
  f(0, n, i) { printf(" %d", a[i]); }
  printf("\n");
}
