#include <bits/stdc++.h>
using namespace std;

#define INF 1e9

struct Edge {
  int v, w;
};

int main() {
  int n;
  cin >> n;

  vector<vector<Edge>> adj(n);

  // input adjacency list
  for (int i = 0; i < n; i++) {
    int cnt;
    cin >> cnt;
    for (int j = 0; j < cnt; j++) {
      int v, w;
      cin >> v >> w;
      adj[i].push_back({v, w});
    }
  }

  vector<int> key(n, INF);
  vector<int> parent(n, -1);
  vector<bool> inMST(n, false);

  key[0] = 0;

  for (int count = 0; count < n - 1; count++) {
    int u = -1, minKey = INF;

    for (int i = 0; i < n; i++) {
      if (!inMST[i] && key[i] < minKey) {
        minKey = key[i];
        u = i;
      }
    }

    inMST[u] = true;

    for (auto e : adj[u]) {
      int v = e.v;
      int w = e.w;

      if (!inMST[v] && w < key[v]) {
        key[v] = w;
        parent[v] = u;
      }
    }
  }

  cout << "MST edges:\n";
  for (int i = 1; i < n; i++) {
    cout << parent[i] << " - " << i << " : " << key[i] << endl;
  }
}
