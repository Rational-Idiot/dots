#include <limits.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct FibNode {
  int key;
  int degree;
  int mark;
  struct FibNode *parent;
  struct FibNode *child;
  struct FibNode *left;
  struct FibNode *right;
} Node;

typedef struct FibHeap {
  Node *min;
  int n;
} Heap;

// Create a new Fibonacci heap
// Time Complexity: O(1)
Heap *makeHeap() {
  Heap *H = malloc(sizeof(Heap));
  H->min = NULL;
  H->n = 0;
  return H;
}

// Create a new Fibonacci heap node
// Time Complexity: O(1)
Node *createNode(int key) {
  Node *x = malloc(sizeof(Node));
  x->key = key;
  x->degree = 0;
  x->mark = 0;
  x->parent = NULL;
  x->child = NULL;
  x->left = x;
  x->right = x;
  return x;
}

// Insert a node into the root list
// Time Complexity: O(1) amortized
void insert(Heap *H, int key) {
  Node *x = createNode(key);

  if (H->min == NULL) {
    H->min = x;
  } else {
    x->right = H->min;
    x->left = H->min->left;
    H->min->left->right = x;
    H->min->left = x;

    if (x->key < H->min->key)
      H->min = x;
  }
  H->n++;
}

// Returns the minimum key
// Time Complexity: O(1)
int findMinimum(Heap *H) {
  if (H->min == NULL)
    return INT_MAX;
  return H->min->key;
}

// Concatenates root lists of two heaps
// Time Complexity: O(1)
Heap *unionHeaps(Heap *H1, Heap *H2) {
  if (H1->min == NULL)
    return H2;
  if (H2->min == NULL)
    return H1;

  Heap *H = makeHeap();

  Node *H1min = H1->min;
  Node *H2min = H2->min;

  H1min->right->left = H2min->left;
  H2min->left->right = H1min->right;
  H1min->right = H2min;
  H2min->left = H1min;

  H->min = (H1min->key < H2min->key) ? H1min : H2min;
  H->n = H1->n + H2->n;

  return H;
}

void printTree(Node *node, int level) {
  if (!node)
    return;

  Node *start = node;
  Node *curr = node;

  do {
    for (int i = 0; i < level; i++)
      printf("  ");

    printf("%d\n", curr->key);

    if (curr->child)
      printTree(curr->child, level + 1);

    curr = curr->right;
  } while (curr != start);
}

void printHeap(Heap *H) {
  if (!H->min) {
    printf("Heap is empty\n");
    return;
  }

  printf("Fibonacci Heap (root list):\n");
  printTree(H->min, 0);
}

int main() {
  Heap *heap1 = makeHeap();
  Heap *heap2 = makeHeap();

  insert(heap1, 10);
  insert(heap1, 3);
  insert(heap1, 7);
  insert(heap1, 1);

  printf("Heap 1:\n");
  printHeap(heap1);
  printf("Minimum in Heap 1: %d\n\n", findMinimum(heap1));

  insert(heap2, 8);
  insert(heap2, 2);
  insert(heap2, 15);

  printf("Heap 2:\n");
  printHeap(heap2);
  printf("Minimum in Heap 2: %d\n\n", findMinimum(heap2));

  Heap *mergedHeap = unionHeaps(heap1, heap2);

  printf("Merged Heap:\n");
  printHeap(mergedHeap);
  printf("Minimum after merging: %d\n", findMinimum(mergedHeap));

  return 0;
}
