// This file implements the problem A and B and uses the minHeap to sort the
// array in descending order

#include <stdio.h>

int heap[100];
int size = 0;

void swap(int *a, int *b) {
  int temp = *a;
  *a = *b;
  *b = temp;
}

void deleteMin(int value) {
  int index = -1;

  for (int i = 0; i < size; i++) {
    if (heap[i] == value) {
      index = i;
      break;
    }
  }
  if (index == -1)
    return;

  heap[index] = heap[size - 1];
  size--;

  while (1) {
    int left = 2 * index + 1;
    int right = 2 * index + 2;
    int smallest = index;

    if (left < size && heap[left] < heap[smallest])
      smallest = left;
    if (right < size && heap[right] < heap[smallest])
      smallest = right;

    if (smallest != index) {
      swap(&heap[index], &heap[smallest]);
      index = smallest;
    } else {
      break;
    }
  }
}

void insert(int value) {
  heap[size] = value;
  int index = size;
  size++;

  while (index > 0 && heap[(index - 1) / 2] > heap[index]) {
    swap(&heap[index], &heap[(index - 1) / 2]);
    index = (index - 1) / 2;
  }
}

void display() {
  for (int i = 0; i < size; i++)
    printf("%d ", heap[i]);
  printf("\n");
}

void heapify(int i, int n) {
  int smallest = i;
  int l = 2 * i + 1;
  int r = 2 * i + 2;

  if (l < n && heap[l] < heap[smallest])
    smallest = l;

  if (r < n && heap[r] < heap[smallest])
    smallest = r;

  if (smallest != i) {
    swap(&heap[i], &heap[smallest]);
    heapify(smallest, n);
  }
}

void heapsort() {
  for (int i = size / 2 - 1; i >= 0; i--)
    heapify(i, size);

  for (int i = size - 1; i > 0; i--) {
    swap(&heap[0], &heap[i]);
    heapify(0, i);
  }
}

void buildMinHeap(int arr[], int n) {
  size = n;
  for (int i = 0; i < n; i++)
    heap[i] = arr[i];

  for (int i = size / 2 - 1; i >= 0; i--)
    heapify(i, size);
}

int top() {
  if (size > 0)
    return heap[0];
  return -1;
}

int main() {
  int arr[] = {50, 10, 20, 30, 5, 90, 80, 100, 85};
  int n = sizeof(arr) / sizeof(arr[0]);
  buildMinHeap(arr, n);

  heapsort();
  display();
}
