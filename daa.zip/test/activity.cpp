#include <bits/stdc++.h>
using namespace std;

struct Activity {
  int start;
  int finish;
};

bool compare(Activity a, Activity b) { return a.finish < b.finish; }

int activitySelection(vector<Activity> acts) {
  sort(acts.begin(), acts.end(), compare);

  int count = 1;
  int lastFinish = acts[0].finish;

  for (int i = 1; i < acts.size(); i++) {
    if (acts[i].start >= lastFinish) {
      count++;
      lastFinish = acts[i].finish;
    }
  }

  return count;
}

int main() {
  vector<Activity> acts = {{1, 3}, {2, 5}, {4, 6}, {6, 7}, {5, 8}, {8, 9}};

  cout << activitySelection(acts) << endl;
}
