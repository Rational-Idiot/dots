#include <bits/stdc++.h>
using namespace std;

#define INF 1e9

struct Edge {
  int u, v, w;
};

int main() {
  int n, m, src;
  cin >> n >> m >> src;

  vector<Edge> edges;

  for (int i = 0; i < m; i++) {
    int u, v, w;
    cin >> u >> v >> w;
    edges.push_back({u, v, w});
  }

  vector<int> dist(n, INF);
  dist[src] = 0;

  // relax edges V-1 times
  for (int i = 1; i <= n - 1; i++) {
    for (auto e : edges) {
      if (dist[e.u] != INF && dist[e.u] + e.w < dist[e.v]) {

        dist[e.v] = dist[e.u] + e.w;
      }
    }
  }

  // check negative weight cycle
  bool negativeCycle = false;

  for (auto e : edges) {
    if (dist[e.u] != INF && dist[e.u] + e.w < dist[e.v]) {
      negativeCycle = true;
      break;
    }
  }

  if (negativeCycle)
    cout << "Negative weight cycle detected\n";
  else {
    for (int i = 0; i < n; i++) {
      cout << "Distance to " << i << " = " << dist[i] << endl;
    }
  }
}
