#include <bits/stdc++.h>
using namespace std;

const int INF = 1e9;

bool dfs(int u, int t, vector<vector<int>> &cap, vector<vector<int>> &adj,
         vector<int> &vis, int flow, int &min_flow) {

  if (u == t) {
    min_flow = flow;
    return true;
  }

  vis[u] = 1;

  for (int v : adj[u]) {
    if (!vis[v] && cap[u][v] > 0) {

      int curr_flow = min(flow, cap[u][v]);

      if (dfs(v, t, cap, adj, vis, curr_flow, min_flow)) {
        cap[u][v] -= min_flow;
        cap[v][u] += min_flow;
        return true;
      }
    }
  }

  return false;
}

int fordFulkerson(int s, int t, vector<vector<int>> &cap,
                  vector<vector<int>> &adj) {

  int flow = 0;

  while (true) {
    vector<int> vis(cap.size(), 0);
    int min_flow = 0;

    if (!dfs(s, t, cap, adj, vis, INF, min_flow))
      break;

    flow += min_flow;
  }

  return flow;
}

int main() {
  int N, M;
  cin >> N >> M;

  int S, T;
  cin >> S >> T;

  vector<vector<int>> cap(N, vector<int>(N, 0));
  vector<vector<int>> adj(N);

  for (int i = 0; i < M; i++) {
    int u, v, c;
    cin >> u >> v >> c;

    cap[u][v] += c;
    adj[u].push_back(v);
    adj[v].push_back(u);
  }

  cout << fordFulkerson(S, T, cap, adj) << endl;
}
