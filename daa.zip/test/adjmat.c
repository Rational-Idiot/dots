#include <stdio.h>
#include <stdlib.h>

#define MAX 100

typedef struct Node {
  int vertex;
  int weight;
  struct Node *next;
} Node;

Node *adj[MAX];

Node *createNode(int v, int w) {
  Node *newNode = (Node *)malloc(sizeof(Node));
  newNode->vertex = v;
  newNode->weight = w;
  newNode->next = NULL;
  return newNode;
}

void addEdge(int u, int v, int w) {
  Node *newNode = createNode(v, w);
  newNode->next = adj[u];
  adj[u] = newNode;
}

int main() {
  int n;
  scanf("%d", &n);

  int mat[MAX][MAX];

  for (int i = 0; i < n; i++)
    for (int j = 0; j < n; j++)
      scanf("%d", &mat[i][j]);

  for (int i = 0; i < n; i++)
    adj[i] = NULL;

  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      if (mat[i][j] != 0) {
        addEdge(i, j, mat[i][j]);
      }
    }
  }

  for (int i = 0; i < n; i++) {
    printf("%d -> ", i);
    Node *temp = adj[i];
    while (temp) {
      printf("(%d, %d) ", temp->vertex, temp->weight);
      temp = temp->next;
    }
    printf("\n");
  }

  return 0;
}
