#include <stdio.h>
#include <stdlib.h>

// Structure representing a dynamic array
typedef struct DynamicArray {
  int *array;
  int capacity;
  int size;
} DArray;

// Initialize dynamic array with given capacity using malloc
DArray *createArray(int capacity) {
  DArray *arr = malloc(sizeof(DArray));
  arr->array = malloc(sizeof(int) * capacity);
  arr->capacity = capacity;
  arr->size = 0;
  return arr;
}

// Initialize dynamic array with given capacity using calloc
DArray *createArrayCalloc(int capacity) {
  DArray *arr = malloc(sizeof(DArray));
  arr->array = calloc(capacity, sizeof(int));
  arr->capacity = capacity;
  arr->size = 0;
  return arr;
}

// Resize the dynamic array (double its capacity)
// Time Complexity: O(n)
void resizeArray(DArray *arr) {
  arr->capacity *= 2;
  arr->array = realloc(arr->array, sizeof(int) * arr->capacity);
}

// Insert an element into dynamic array
// Amortized Time Complexity: O(1)
void insertElement(DArray *arr, int value) {
  if (arr->size == arr->capacity) {
    resizeArray(arr); // Resize if capacity is full
  }
  arr->array[arr->size] = value;
  arr->size++;
}

// Print the dynamic array
void printArray(DArray *arr) {
  printf("Array (size: %d, capacity: %d): ", arr->size, arr->capacity);
  for (int i = 0; i < arr->size; i++)
    printf("%d ", arr->array[i]);
  printf("\n");
}

int main() {
  DArray *arr = createArray(4);

  for (int i = 1; i <= 10; i++) {
    insertElement(arr, i);
    printArray(arr);
  }

  free(arr->array);
  free(arr);

  return 0;
}
