// This file implements the bucket sort algorithm to efficiently manage and sort
// sections of numbers which cannot be sorted normally like floats
#include <stdio.h>
#include <stdlib.h>

struct Node {
  float data;
  struct Node *next;
};

struct Node *createNode(float value) {
  struct Node *newNode = (struct Node *)malloc(sizeof(struct Node));
  newNode->data = value;
  newNode->next = NULL;
  return newNode;
}

void insertSorted(struct Node **head, float value) {
  struct Node *newNode = createNode(value);

  if (*head == NULL || (*head)->data >= value) {
    newNode->next = *head;
    *head = newNode;
    return;
  }

  struct Node *current = *head;
  while (current->next != NULL && current->next->data < value) {
    current = current->next;
  }

  newNode->next = current->next;
  current->next = newNode;
}

void bucketSort(float arr[], int n) {
  struct Node **buckets = (struct Node **)malloc(n * sizeof(struct Node *));

  for (int i = 0; i < n; i++)
    buckets[i] = NULL;

  for (int i = 0; i < n; i++) {
    int bucketIndex = n * arr[i];

    if (bucketIndex >= n)
      bucketIndex = n - 1;

    insertSorted(&buckets[bucketIndex], arr[i]);
  }

  int index = 0;
  for (int i = 0; i < n; i++) {
    struct Node *current = buckets[i];
    while (current != NULL) {
      arr[index++] = current->data;
      struct Node *temp = current;
      current = current->next;
      free(temp);
    }
  }

  free(buckets);
}

int main() {
  float arr[] = {0.897, 0.565, 0.656, 0.1234, 0.665, 0.3434};
  int n = sizeof(arr) / sizeof(arr[0]);

  printf("Original Array:\n");
  for (int i = 0; i < n; i++)
    printf("%.4f ", arr[i]);
  printf("\n");

  bucketSort(arr, n);

  printf("Sorted Array:\n");
  for (int i = 0; i < n; i++)
    printf("%.4f ", arr[i]);
  printf("\n");

  return 0;
}
