// This file implements the MinHeap to find the kth smallest element by
// repeatedly calling heapify and finding it in klogn time
#include <stdio.h>

int heap[100];
int size = 0;

void swap(int *a, int *b) {
  int temp = *a;
  *a = *b;
  *b = temp;
}

void heapify(int i, int n) {
  int largest = i;
  int l = 2 * i + 1;
  int r = 2 * i + 2;

  if (l < n && heap[l] > heap[largest])
    largest = l;

  if (r < n && heap[r] > heap[largest])
    largest = r;

  if (largest != i) {
    swap(&heap[i], &heap[largest]);
    heapify(largest, n);
  }
}

void buildMinHeap(int arr[], int n) {
  size = n;
  for (int i = 0; i < n; i++)
    heap[i] = arr[i];

  for (int i = size / 2 - 1; i >= 0; i--)
    heapify(i, size);
}

void replaceMax(int value) {
  heap[0] = value;
  heapify(0, size);
}

int kthSmallest(int arr[], int n, int k) {
  buildMinHeap(arr, k);

  for (int i = k; i < n; i++) {
    if (arr[i] < heap[0]) {
      replaceMax(arr[i]);
    }
  }

  return heap[0];
}

int main() {
  int elements[] = {50, 10, 20, 30, 5, 90, 80, 100, 85};
  int n = sizeof(elements) / sizeof(elements[0]);
  int k;

  printf("Elements: ");
  for (int i = 0; i < n; i++)
    printf("%d ", elements[i]);
  printf("\n");

  printf("Enter K to find the Kth minimum element: ");
  scanf("%d", &k);

  if (k > 0 && k <= n) {
    int result = kthSmallest(elements, n, k);
    printf("The %d-th minimum element is: %d\n", k, result);
  } else {
    printf("Invalid K\n");
  }

  return 0;
}
