#include <bits/stdc++.h>
using namespace std;

const int INF = 1e9;

bool bfs(int s, int t, vector<vector<int>> &cap, vector<vector<int>> &adj,
         vector<int> &parent) {

  fill(parent.begin(), parent.end(), -1);
  parent[s] = -2;

  queue<int> q;
  q.push(s);

  while (!q.empty()) {
    int u = q.front();
    q.pop();

    for (int v : adj[u]) {
      if (parent[v] == -1 && cap[u][v] > 0) {
        parent[v] = u;
        q.push(v);
      }
    }
  }

  return parent[t] != -1;
}

int maxFlow(int s, int t, vector<vector<int>> &cap, vector<vector<int>> &adj) {

  int flow = 0;
  vector<int> parent(cap.size());

  while (bfs(s, t, cap, adj, parent)) {

    int path_flow = INF;

    for (int v = t; v != s; v = parent[v]) {
      int u = parent[v];
      path_flow = min(path_flow, cap[u][v]);
    }

    for (int v = t; v != s; v = parent[v]) {
      int u = parent[v];
      cap[u][v] -= path_flow;
      cap[v][u] += path_flow;
    }

    flow += path_flow;
  }

  return flow;
}

int main() {

  int N, M;
  cin >> N >> M;

  int V = N + 2;

  int SS = 0;
  int TT = N + 1;

  vector<vector<int>> cap(V, vector<int>(V, 0));
  vector<vector<int>> adj(V);

  int S_count;
  cin >> S_count;

  vector<int> sources(S_count);
  for (int i = 0; i < S_count; i++) {
    cin >> sources[i];

    cap[SS][sources[i]] = INF;
    adj[SS].push_back(sources[i]);
    adj[sources[i]].push_back(SS);
  }

  int T_count;
  cin >> T_count;

  vector<int> sinks(T_count);
  for (int i = 0; i < T_count; i++) {
    cin >> sinks[i];

    cap[sinks[i]][TT] = INF;
    adj[sinks[i]].push_back(TT);
    adj[TT].push_back(sinks[i]);
  }

  for (int i = 0; i < M; i++) {
    int u, v, c;
    cin >> u >> v >> c;

    cap[u][v] += c;
    adj[u].push_back(v);
    adj[v].push_back(u);
  }

  cout << "Max Flow = " << maxFlow(SS, TT, cap, adj) << endl;

  return 0;
}
