
#include <stdio.h>

int getMax(int arr[], int n) {
  int mx = arr[0];
  for (int i = 1; i < n; i++) {
    mx = (arr[i] > mx) ? arr[i] : mx;
  }
  return mx;
}

void countSort(int arr[], int n, int exp) {
  int output[n];
  int count[10] = {0};

  for (int i = 0; i < n; i++) {
    int idx = (arr[i] / exp) % 10;
    count[idx]++;
  }

  for (int i = 1; i < 10; i++) {
    count[i] = count[i] + count[i - 1];
  }

  for (int i = n; i-- > 0;) {
    int idx = (arr[i] / exp) % 10;
    output[count[idx] - 1] = arr[i];
    count[idx]--;
  }

  for (int i = 0; i < n; i++) {
    arr[i] = output[i];
  }
}

void radixSort(int arr[], int n) {
  int m = getMax(arr, n);
  for (int exp = 1; exp <= m; exp *= 10)
    countSort(arr, n, exp);
}

int main() {
  int n;
  scanf("%d", &n);
  int arr[n];
  for (int i = 0; i < n; i++) {
    scanf("%d", &arr[i]);
  }

  radixSort(arr, n);
  for (int i = 0; i < n; i++) {
    printf("%d ", arr[i]);
  }

  return 0;
}
