#include <bits/stdc++.h>
using namespace std;

void radixSort(vector<int> &a) {
  int m = *max_element(a.begin(), a.end());

  for (int exp = 1; m / exp > 0; exp *= 10) {
    vector<vector<int>> bucket(10);

    for (int x : a)
      bucket[(x / exp) % 10].push_back(x);

    int k = 0;
    for (auto &b : bucket)
      for (int x : b)
        a[k++] = x;
  }
}

int main() {
  vector<int> a = {170, 45, 75, 90, 802, 24, 2, 66};

  radixSort(a);

  for (int x : a)
    cout << x << " ";
}
