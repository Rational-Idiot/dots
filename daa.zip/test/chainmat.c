#include <limits.h>
#include <stdio.h>

#define MIN(a, b) ((a) <= (b) ? (a) : (b))

int Chain(int arr[], int n) {
  int dp[n][n];
  for (int i = 1; i < n; i++)
    dp[i][i] = 0;

  for (int L = 2; L <= n - 1; L++) {
    for (int i = 1; i + L - 1 < n; i++) {

      int j = i + L - 1;
      dp[i][j] = INT_MAX;
      for (int k = i; k != j; k++) {
        int cost = dp[i][k] + dp[k + 1][j];
        cost += arr[i - 1] * arr[k] * arr[j];
        dp[i][j] = MIN(dp[i][j], cost);
      }
    }
  }
  return dp[1][n - 1];
}

int main() {
  int n;
  scanf("%d", &n);
  int arr[n];
  for (int i = 0; i < n; i++) {
    scanf("%d", &arr[i]);
  }
  printf("%d\n", Chain(arr, n));
  return 0;
}
