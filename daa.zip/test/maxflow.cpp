#include <bits/stdc++.h>
using namespace std;

const int INF = 1e9;

/* ---------------- BFS for augmenting path ---------------- */
bool bfs(int s, int t, vector<vector<int>> &cap, vector<vector<int>> &adj,
         vector<int> &parent) {

  fill(parent.begin(), parent.end(), -1);
  parent[s] = -2;

  queue<int> q;
  q.push(s);

  while (!q.empty()) {
    int u = q.front();
    q.pop();

    for (int v : adj[u]) {
      if (parent[v] == -1 && cap[u][v] > 0) {
        parent[v] = u;
        q.push(v);
      }
    }
  }

  return parent[t] != -1;
}

/* ---------------- Max Flow ---------------- */
int maxFlow(int s, int t, vector<vector<int>> &cap, vector<vector<int>> &adj) {

  int flow = 0;
  vector<int> parent(cap.size());

  while (bfs(s, t, cap, adj, parent)) {

    int path_flow = INF;

    // find bottleneck
    for (int v = t; v != s; v = parent[v]) {
      int u = parent[v];
      path_flow = min(path_flow, cap[u][v]);
    }

    // update residual graph
    for (int v = t; v != s; v = parent[v]) {
      int u = parent[v];
      cap[u][v] -= path_flow;
      cap[v][u] += path_flow;
    }

    flow += path_flow;
  }

  return flow;
}

/* ---------------- DFS/BFS reachability for Min Cut ---------------- */
void dfs(int u, vector<vector<int>> &cap, vector<vector<int>> &adj,
         vector<bool> &vis) {

  vis[u] = true;

  for (int v : adj[u]) {
    if (!vis[v] && cap[u][v] > 0) {
      dfs(v, cap, adj, vis);
    }
  }
}

/* ---------------- MAIN ---------------- */
int main() {

  int N, M;
  cin >> N >> M;

  int S, T;
  cin >> S >> T;

  vector<vector<int>> cap(N, vector<int>(N, 0));
  vector<vector<int>> adj(N);

  /* input edges */
  for (int i = 0; i < M; i++) {
    int u, v, c;
    cin >> u >> v >> c;

    cap[u][v] += c;
    adj[u].push_back(v);
    adj[v].push_back(u); // reverse edge
  }

  /* MAX FLOW */
  int max_flow = maxFlow(S, T, cap, adj);

  cout << "Max Flow = " << max_flow << endl;

  /* MIN CUT */
  vector<bool> vis(N, false);
  dfs(S, cap, adj, vis);

  cout << "Min Cut Edges:\n";

  for (int u = 0; u < N; u++) {
    for (int v : adj[u]) {
      if (vis[u] && !vis[v] && cap[u][v] == 0) {
        cout << u << " - " << v << endl;
      }
    }
  }

  return 0;
}
