#include <limits.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct Noded {
  int key;
  int degree;
  struct Noded *parent;
  struct Noded *child;
  struct Noded *sibling;
} Node;

typedef struct Heapd {
  Node *head;
} Heap;

// Creates a new binomial node
// Time Complexity- O(1)
Node *createNode(int key) {
  Node *node = malloc(sizeof(Node));
  node->key = key;
  node->degree = 0;
  node->parent = NULL;
  node->child = NULL;
  node->sibling = NULL;
  return node;
}

// Creates an empty binomial heap
// Time Complexity- O(1)
Heap *makeHeap() {
  Heap *heap = malloc(sizeof(Heap));
  heap->head = NULL;
  return heap;
}

// Links two binomial trees of the same degree
// Time Complexity- O(1)
void binomialLink(Node *y, Node *z) {
  y->parent = z;
  y->sibling = z->child;
  z->child = y;
  z->degree++;
}

// Merges two root lists sorted by degree
// Time Complexity- O(log n)
Node *mergeRootLists(Node *h1, Node *h2) {
  if (!h1)
    return h2;
  if (!h2)
    return h1;

  Node *head;
  Node *tail;

  if (h1->degree <= h2->degree) {
    head = h1;
    h1 = h1->sibling;
  } else {
    head = h2;
    h2 = h2->sibling;
  }

  tail = head;

  while (h1 && h2) {
    if (h1->degree <= h2->degree) {
      tail->sibling = h1;
      h1 = h1->sibling;
    } else {
      tail->sibling = h2;
      h2 = h2->sibling;
    }
    tail = tail->sibling;
  }

  tail->sibling = h1 ? h1 : h2;
  return head;
}

// Unions two binomial heaps into one
// Time Complexity- O(log n)
Heap *unionHeaps(Heap *h1, Heap *h2) {
  Heap *h = makeHeap();
  h->head = mergeRootLists(h1->head, h2->head);

  if (!h->head)
    return h;

  Node *prev = NULL;
  Node *curr = h->head;
  Node *next = curr->sibling;

  while (next) {
    if (curr->degree != next->degree ||
        (next->sibling && next->sibling->degree == curr->degree)) {
      prev = curr;
      curr = next;
    } else {
      if (curr->key <= next->key) {
        curr->sibling = next->sibling;
        binomialLink(next, curr);
      } else {
        if (!prev)
          h->head = next;
        else
          prev->sibling = next;
        binomialLink(curr, next);
        curr = next;
      }
    }
    next = curr->sibling;
  }

  return h;
}

// Inserts a key into the binomial heap
// Time Complexity- O(log n)
void insert(Heap *heap, int key) {
  Heap *temp = makeHeap();
  temp->head = createNode(key);
  Heap *newHeap = unionHeaps(heap, temp);
  heap->head = newHeap->head;
}

// Finds and returns the minimum key in the heap
// Time Complexity- O(log n)
int findMin(Heap *heap) {
  if (!heap->head)
    return INT_MAX;

  int min = INT_MAX;
  Node *curr = heap->head;

  while (curr) {
    if (curr->key < min)
      min = curr->key;
    curr = curr->sibling;
  }

  return min;
}

void printTree(Node *node, int level) {
  if (!node)
    return;

  for (int i = 0; i < level; i++)
    printf("  ");

  printf("%d\n", node->key);

  printTree(node->child, level + 1);
  printTree(node->sibling, level);
}

void printHeap(Heap *heap) {
  if (!heap->head) {
    printf("Heap is empty\n");
    return;
  }

  Node *curr = heap->head;
  int treeNum = 0;

  while (curr) {
    printf("Binomial Tree B%d:\n", curr->degree);
    printTree(curr, 0);
    curr = curr->sibling;
    treeNum++;
  }
}

int main() {
  Heap *heap1 = makeHeap();
  Heap *heap2 = makeHeap();

  insert(heap1, 10);
  insert(heap1, 3);
  insert(heap1, 7);
  insert(heap1, 1);
  printHeap(heap1);
  printf("\n");

  printf("Minimum in Heap 1: %d\n", findMin(heap1));

  insert(heap2, 8);
  insert(heap2, 2);
  insert(heap2, 15);
  printHeap(heap2);
  printf("\n");

  printf("Minimum in Heap 2: %d\n", findMin(heap2));

  Heap *mergedHeap = unionHeaps(heap1, heap2);

  printf("Minimum after merging Heap 1 and Heap 2: %d\n", findMin(mergedHeap));

  return 0;
}
