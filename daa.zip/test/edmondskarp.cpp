#include <bits/stdc++.h>
using namespace std;

const int INF = 1e9;

int bfs(int s, int t, vector<vector<int>> &cap, vector<vector<int>> &adj,
        vector<int> &parent) {

  fill(parent.begin(), parent.end(), -1);
  parent[s] = -2;

  queue<pair<int, int>> q;
  q.push({s, INF});

  while (!q.empty()) {
    int u = q.front().first;
    int flow = q.front().second;
    q.pop();

    for (int v : adj[u]) {
      if (parent[v] == -1 && cap[u][v] > 0) {

        parent[v] = u;

        int new_flow = min(flow, cap[u][v]);

        if (v == t)
          return new_flow;

        q.push({v, new_flow});
      }
    }
  }

  return 0;
}

int edmondsKarp(int s, int t, vector<vector<int>> &cap,
                vector<vector<int>> &adj) {

  int flow = 0;
  vector<int> parent(cap.size());

  int new_flow;

  while ((new_flow = bfs(s, t, cap, adj, parent))) {
    flow += new_flow;

    int cur = t;
    while (cur != s) {
      int prev = parent[cur];
      cap[prev][cur] -= new_flow;
      cap[cur][prev] += new_flow;
      cur = prev;
    }
  }

  return flow;
}

int main() {
  int N, M;
  cin >> N >> M;

  int S, T;
  cin >> S >> T;

  vector<vector<int>> cap(N, vector<int>(N, 0));
  vector<vector<int>> adj(N);

  for (int i = 0; i < M; i++) {
    int u, v, c;
    cin >> u >> v >> c;

    cap[u][v] += c;
    adj[u].push_back(v);
    adj[v].push_back(u);
  }

  cout << edmondsKarp(S, T, cap, adj) << endl;
}
