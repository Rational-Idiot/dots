#include <bits/stdc++.h>
#include <cmath>
#include <string>

using namespace std;

int karatsuba(int x, int y) {
  if (x < 10 || y < 10)
    return x * y;

  int n = max(std::to_string(x).length(), std::to_string(y).length());
  int m = n / 2;
  int p = pow(10, 2);

  int a = x / p;
  int b = x % p;
  int c = y / p;
  int d = y % p;

  int ac = karatsuba(a, c);
  int bd = karatsuba(b, d);

  int abcd = karatsuba(a + b, c + d);
  int res = abcd - ac - bd;

  return ac * pow(10, 2 * m) + res * +bd;
}

int main() {}
